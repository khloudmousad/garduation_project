# smarthelmet (IOT Safety HW Helmet connected to SW Mobile app - Graduation Project Using Flutter and Dart programming language ))


# smart Safety helmet SW Mobile App


The discussion was with Prof. Dr. Ahmed Said and Prof. Dr.  Hania Farag at the faculty of engineering, Alexandria university .. we got a grade of A ( equal to a GPA of 4 out of 4)


The Project Demo Video:

(https://drive.google.com/file/d/1KyRRI7kLIveABft17Lilg12LsriE-RWR/view?usp=drive_link)



The Project presentation slides:

https://docs.google.com/presentation/d/1AIYYr7sZVSren1u-P9b_R9TDCue93LW2/edit?usp=drive_link&ouid=114810985550305975313&rtpof=true&sd=true


The Full Book Documentation of SW and HW parts:

https://drive.google.com/file/d/1pH1YRO0ARxKWdC07mmQ6SoznHRYjRrhh/view?usp=sharing



The Discussions Day Live Videos:

https://drive.google.com/drive/folders/1-0sUXn8At5m9mPMxUqQZK12NXqspRPpx



======================================================================================================================================================

Some Other useful links for More info:

=====================

** More Detailed SW Visualization:
1. Sensors:
   
https://drive.google.com/file/d/1ggjrixRBY6DkNbAiAJGnxBBgBUaiCGH_/view?usp=sharing

3. Notifications:
   
https://drive.google.com/file/d/121OQ8lRMtm3iqbA0O8GiSStzcKtSCAp4/view?usp=drive_link

5. Emergency:
   
https://drive.google.com/file/d/19MYVdIUE_ph_1HMq8IdE67C44rCe1tCQ/view?usp=sharing


** General other Visualizations:

[some other useful visualization.pdf](https://github.com/user-attachments/files/16605673/some.other.useful.visualization.pdf)




