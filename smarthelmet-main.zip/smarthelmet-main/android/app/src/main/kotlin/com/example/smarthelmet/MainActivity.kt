package com.example.smarthelmet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
