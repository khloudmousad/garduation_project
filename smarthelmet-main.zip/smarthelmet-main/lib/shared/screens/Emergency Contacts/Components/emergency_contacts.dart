class EmergencyContacts {
  final String initials, name, contactNo;

  EmergencyContacts(this.initials, this.name, this.contactNo);
}
