import 'package:flutter/material.dart';

Color navBarColor = Colors.amber;